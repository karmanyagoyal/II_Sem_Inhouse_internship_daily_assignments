// Initialize local storage keys if empty
if (!localStorage.getItem('surveys')) {
    localStorage.setItem('surveys', JSON.stringify([]));
}

let activeSurveyId = null;

// Dark Mode Management
function initTheme() {
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    if (isDarkMode) {
        document.body.classList.add('dark-mode');
        document.getElementById('theme-toggle-btn').innerText = '☀️ Light Mode';
    }
}

function toggleDarkMode() {
    const isDark = document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', isDark);
    document.getElementById('theme-toggle-btn').innerText = isDark ? '☀️ Light Mode' : '🌙 Dark Mode';
}

// Tab Switching
function showTab(event, tabId) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));

    document.getElementById(tabId).classList.add('active');
    event.target.classList.add('active');

    if (tabId === 'take-tab') renderTakeSurveyList();
    if (tabId === 'results-tab') renderResults();
}

// 1. CREATE SURVEY
document.getElementById('create-survey-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const title = document.getElementById('survey-title').value;
    const question = document.getElementById('survey-question').value;
    const optionInputs = document.querySelectorAll('.survey-option');
    
    const options = Array.from(optionInputs).map(input => ({
        text: input.value,
        votes: 0
    }));

    const newSurvey = {
        id: Date.now(),
        title,
        question,
        options
    };

    const surveys = JSON.parse(localStorage.getItem('surveys'));
    surveys.push(newSurvey);
    localStorage.setItem('surveys', JSON.stringify(surveys));

    alert('Survey created successfully!');
    this.reset();
});

// 2. RENDER LIST OF SURVEYS TO ANSWER
function renderTakeSurveyList() {
    const listContainer = document.getElementById('survey-list');
    const surveys = JSON.parse(localStorage.getItem('surveys'));
    
    listContainer.innerHTML = '';
    document.getElementById('active-survey-container').classList.add('hidden');

    if (surveys.length === 0) {
        listContainer.innerHTML = '<p>No surveys available. Create one first!</p>';
        return;
    }

    surveys.forEach(survey => {
        const card = document.createElement('div');
        card.className = 'survey-card';
        card.innerHTML = `
            <div class="survey-card-header">
                <div class="survey-card-title" onclick="loadSurvey(${survey.id})">
                    <strong>${survey.title}</strong>
                </div>
                <button class="btn-danger" onclick="deleteSurvey(${survey.id})">Delete</button>
            </div>
        `;
        listContainer.appendChild(card);
    });
}

// LOAD SELECTED SURVEY FOR ANSWERING
function loadSurvey(surveyId) {
    activeSurveyId = surveyId;
    const surveys = JSON.parse(localStorage.getItem('surveys'));
    const survey = surveys.find(s => s.id === surveyId);

    document.getElementById('display-title').innerText = survey.title;
    document.getElementById('display-question').innerText = survey.question;

    const optionsContainer = document.getElementById('options-container');
    optionsContainer.innerHTML = '';

    survey.options.forEach((opt, index) => {
        const optionDiv = document.createElement('div');
        optionDiv.className = 'option-group';
        optionDiv.innerHTML = `
            <input type="radio" id="opt-${index}" name="survey-opt" value="${index}" required>
            <label for="opt-${index}" style="display:inline; margin-left: 5px;">${opt.text}</label>
        `;
        optionsContainer.appendChild(optionDiv);
    });

    document.getElementById('active-survey-container').classList.remove('hidden');
}

// SUBMIT SURVEY ANSWER
document.getElementById('take-survey-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const selectedOptionIndex = document.querySelector('input[name="survey-opt"]:checked').value;
    const surveys = JSON.parse(localStorage.getItem('surveys'));
    
    const surveyIndex = surveys.findIndex(s => s.id === activeSurveyId);
    surveys[surveyIndex].options[selectedOptionIndex].votes += 1;

    localStorage.setItem('surveys', JSON.stringify(surveys));

    alert('Thank you for submitting your response!');
    renderTakeSurveyList();
});

// 3. RENDER RESULTS
function renderResults() {
    const resultsContainer = document.getElementById('results-list');
    const surveys = JSON.parse(localStorage.getItem('surveys'));

    resultsContainer.innerHTML = '';

    if (surveys.length === 0) {
        resultsContainer.innerHTML = '<p>No survey results available.</p>';
        return;
    }

    surveys.forEach(survey => {
        const totalVotes = survey.options.reduce((sum, opt) => sum + opt.votes, 0);

        let resultsHTML = `
            <div class="survey-card">
                <div class="survey-card-header">
                    <h3>${survey.title}</h3>
                    <button class="btn-danger" onclick="deleteSurvey(${survey.id})">Delete</button>
                </div>
                <p><strong>Question:</strong> ${survey.question}</p>
                <small>Total Responses: ${totalVotes}</small>
                <hr style="margin: 10px 0; border-color: var(--border-color);">
        `;

        survey.options.forEach(opt => {
            const percentage = totalVotes > 0 ? ((opt.votes / totalVotes) * 100).toFixed(1) : 0;
            resultsHTML += `
                <div class="result-bar-container">
                    <span>${opt.text} — <strong>${opt.votes} votes (${percentage}%)</strong></span>
                    <div class="result-bar-bg">
                        <div class="result-bar" style="width: ${percentage}%;"></div>
                    </div>
                </div>
            `;
        });

        resultsHTML += `</div>`;
        resultsContainer.innerHTML += resultsHTML;
    });
}

// 4. DELETE SURVEY FUNCTION
function deleteSurvey(surveyId) {
    if (confirm('Are you sure you want to delete this survey?')) {
        let surveys = JSON.parse(localStorage.getItem('surveys'));
        surveys = surveys.filter(survey => survey.id !== surveyId);
        localStorage.setItem('surveys', JSON.stringify(surveys));

        // Re-render current tab
        if (document.getElementById('take-tab').classList.contains('active')) {
            renderTakeSurveyList();
        } else if (document.getElementById('results-tab').classList.contains('active')) {
            renderResults();
        }
    }
}

// Initialize theme on load
initTheme();